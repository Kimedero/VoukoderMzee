<img src="https://img.shields.io/github/downloads/vouk/voukoder/total.svg">

<p align="center"><img src="https://www.voukoder.org/__resources/logo128.png" width="128" height="128">
<br><a href="https://www.voukoder.org" style="font-size:20pt;">INFOS & DOWNLOAD HERE: WWW.VOUKODER.ORG</a></p>

**Available application connectors:**

Find these connectors at the [application connectors page](https://github.com/Vouk/voukoder-connectors):
- Adobe Premiere / Media Encoder
- Adobe After Effects
- DaVinci Resolve
- VEGAS Pro
- VirtualDub 2

**Stay up-to-date, discuss on the forums and get all announcements and news at https://www.voukoder.org.**
- Patreon: https://www.patreon.com/voukoder
- Paypal: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=S6LGDW9QZYBTL&source=url
- Twitter: https://twitter.com/LordVouk
